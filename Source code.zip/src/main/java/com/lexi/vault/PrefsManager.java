package com.lexi.vault;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PrefsManager {
    private static final String PREF_NAME = "lexivault_prefs";
    private static final String KEY_ITEMS = "vault_items";
    private static PrefsManager instance;
    private SharedPreferences sharedPreferences;

    private PrefsManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized PrefsManager getInstance(Context context) {
        if (instance == null) {
            instance = new PrefsManager(context.getApplicationContext());
        }
        return instance;
    }

    // Load full list of secured items. Seed if empty.
    public List<VaultItem> getItems() {
        String json = sharedPreferences.getString(KEY_ITEMS, null);
        if (json == null) {
            List<VaultItem> seed = getSeedData();
            saveItems(seed);
            return seed;
        }
        
        List<VaultItem> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                list.add(VaultItem.fromJSONObject(arr.getJSONObject(i)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Save full items list back to local persistence file
    public void saveItems(List<VaultItem> items) {
        try {
            JSONArray arr = new JSONArray();
            for (VaultItem item : items) {
                arr.put(item.toJSONObject());
            }
            sharedPreferences.edit().putString(KEY_ITEMS, arr.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Delete item by ID
    public void deleteItem(String id) {
        List<VaultItem> list = getItems();
        List<VaultItem> filtered = new ArrayList<>();
        for (VaultItem item : list) {
            if (!item.getId().equals(id)) {
                filtered.add(item);
            }
        }
        saveItems(filtered);
    }

    // Add or Update single item
    public void saveSingleItem(VaultItem item) {
        List<VaultItem> list = getItems();
        boolean replaced = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(item.getId())) {
                list.set(i, item);
                replaced = true;
                break;
            }
        }
        if (!replaced) {
            list.add(0, item); // Prepend to top
        }
        saveItems(list);
    }

    private List<VaultItem> getSeedData() {
        List<VaultItem> list = new ArrayList<>();
        long now = System.currentTimeMillis();

        // Regex
        VaultItem r1 = new VaultItem("regex-1", "regex", now - 300000);
        r1.setDescription("Email Address Validator");
        r1.setSearch("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
        r1.setReplace("");
        list.add(r1);

        VaultItem r2 = new VaultItem("regex-2", "regex", now - 600000);
        r2.setDescription("Secure Password Inspector");
        r2.setSearch("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");
        r2.setReplace("");
        list.add(r2);

        VaultItem r3 = new VaultItem("regex-3", "regex", now - 900000);
        r3.setDescription("Extract YouTube Video ID");
        r3.setSearch("(?:youtube\\.com\\/(?:[^\\/]+\\/.+\\/|(?:v|e(?:mbed)?)\\/|.*[?&]v=)|youtu\\.be\\/)([^\"&?\\/\\s]{11})");
        r3.setReplace("$1");
        list.add(r3);

        VaultItem r4 = new VaultItem("regex-4", "regex", now - 1200000);
        r4.setDescription("Match IPv4 Address");
        r4.setSearch("^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
        r4.setReplace("");
        list.add(r4);

        // Termux Codes
        VaultItem t1 = new VaultItem("termux-1", "termux", now - 60000);
        t1.setDescription("Full System Upgrade & Clean");
        t1.setCodes(Arrays.asList("apt update && apt upgrade -y", "pkg autoclean", "pkg clean"));
        list.add(t1);

        VaultItem t2 = new VaultItem("termux-2", "termux", now - 120000);
        t2.setDescription("Setup Storage & Symbolic Links");
        t2.setCodes(Arrays.asList("termux-setup-storage"));
        list.add(t2);

        VaultItem t3 = new VaultItem("termux-3", "termux", now - 180000);
        t3.setDescription("Install Node.js & Yarn Env");
        t3.setCodes(Arrays.asList("pkg install nodejs -y", "pkg install yarn -y", "node -v && npm -v && yarn -v"));
        list.add(t3);

        VaultItem t4 = new VaultItem("termux-4", "termux", now - 240000);
        t4.setDescription("Python 3 Developer Stack");
        t4.setCodes(Arrays.asList("pkg install python -y", "pip install --upgrade pip", "pip install virtualenv requests"));
        list.add(t4);

        // Links
        VaultItem l1 = new VaultItem("link-1", "links", now - 1800000);
        l1.setName("SR7 Mods App Store");
        l1.setDescription("https://alexsifatrayhan.github.io/sr7mods-app-store/");
        list.add(l1);

        VaultItem l2 = new VaultItem("link-2", "links", now - 1900000);
        l2.setName("SR7 Mods Official Telegram Channel");
        l2.setDescription("https://t.me/sr7mods");
        list.add(l2);

        VaultItem l3 = new VaultItem("link-3", "links", now - 2000000);
        l3.setName("GitHub Profile Sifat Rayhan");
        l3.setDescription("https://github.com/alexsifatrayhan");
        list.add(l3);

        // Clipboard
        VaultItem c1 = new VaultItem("clip-1", "clipboard", now - 2400000);
        c1.setContent("git config --global user.name \"SR7 Mods\" && git config --global user.email \"mrsrff12@gmail.com\"");
        list.add(c1);

        VaultItem c2 = new VaultItem("clip-2", "clipboard", now - 2500000);
        c2.setContent("const chunkArray = (arr, size) => Array.from({ length: Math.ceil(arr.length / size) }, (v, i) => arr.slice(i * size, i * size + size));");
        list.add(c2);

        // Movies
        VaultItem m1 = new VaultItem("movie-1", "movies", now - 3000000);
        m1.setName("Interstellar");
        m1.setDescription("Masterpiece by Nolan exploring gravity, space-time dilation, and black holes.");
        list.add(m1);

        VaultItem m2 = new VaultItem("movie-2", "movies", now - 3100000);
        m2.setName("The Matrix");
        m2.setDescription("A cyber security hacker learns about the true nature of his reality.");
        list.add(m2);

        // Anime
        VaultItem a1 = new VaultItem("anime-1", "anime", now - 3600000);
        a1.setName("Death Note");
        a1.setDescription("A battle of high-level brains between Light Yagami (Kira) and L.");
        list.add(a1);

        VaultItem a2 = new VaultItem("anime-2", "anime", now - 3700000);
        a2.setName("Steins;Gate");
        a2.setDescription("The ultimate time-travel scientific thriller with Okabe Rintarou.");
        list.add(a2);

        return list;
    }
}
