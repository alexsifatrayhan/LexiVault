package com.lexi.vault;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class VaultListAdapter extends BaseAdapter {

    private List<VaultItem> items;
    private List<VaultItem> itemsFull; // Copy for filtering
    private Context context;
    private OnItemActionListener listener;

    public interface OnItemActionListener {
        void onEdit(VaultItem item);
        void onDelete(VaultItem item);
    }

    public VaultListAdapter(Context context, List<VaultItem> items, OnItemActionListener listener) {
        this.context = context;
        this.items = items;
        this.itemsFull = new ArrayList<>(items);
        this.listener = listener;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_vault, parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final VaultItem item = items.get(position);

        // Standard actions
        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) listener.onEdit(item);
            }
        });
        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) listener.onDelete(item);
            }
        });

        // Suppress category-specific groups temporarily
        holder.layoutRegex.setVisibility(View.GONE);
        holder.layoutTermux.setVisibility(View.GONE);
        holder.layoutLinks.setVisibility(View.GONE);
        holder.layoutClipboard.setVisibility(View.GONE);
        holder.layoutGeneral.setVisibility(View.GONE);
        holder.txtCardBadge.setVisibility(View.GONE);

        String categoryStyle = item.getType();

        if ("regex".equals(categoryStyle)) {
            holder.layoutRegex.setVisibility(View.VISIBLE);
            holder.txtTitle.setText(item.getDescription());
            holder.txtDescription.setText("Dynamic string matcher");
            holder.txtDescription.setVisibility(View.VISIBLE);
            
            holder.txtRegexSearch.setText(item.getSearch());
            holder.btnCopySearch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    copyToClipboard("Regex Search Pattern", item.getSearch());
                }
            });

            if (item.getReplace().length() > 0) {
                holder.layoutRegexReplace.setVisibility(View.VISIBLE);
                holder.txtRegexReplace.setText(item.getReplace());
                holder.btnCopyReplace.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        copyToClipboard("Regex Replace Substitution", item.getReplace());
                    }
                });
            } else {
                holder.layoutRegexReplace.setVisibility(View.GONE);
            }

        } else if ("termux".equals(categoryStyle)) {
            holder.layoutTermux.setVisibility(View.VISIBLE);
            holder.txtTitle.setText(item.getDescription());
            holder.txtDescription.setText("Termux command steps");
            holder.txtDescription.setVisibility(View.VISIBLE);

            // Populate rows programmatically
            holder.termuxCommandsContainer.removeAllViews();
            final List<String> codesList = item.getCodes();
            for (int i = 0; i < codesList.size(); i++) {
                final String code = codesList.get(i);
                TextView rowText = new TextView(context);
                rowText.setText(code);
                rowText.setTextColor(context.getResources().getColor(R.color.neon_green));
                rowText.setTextSize(12);
                rowText.setPadding(8, 8, 8, 8);
                rowText.setBackgroundColor(0x22000000);
                
                rowText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        copyToClipboard("Bash Command", code);
                    }
                });
                
                holder.termuxCommandsContainer.addView(rowText);
            }

            holder.btnCopyAllTermux.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    StringBuilder sb = new StringBuilder();
                    for (String code : codesList) {
                        sb.append(code).append("\n");
                    }
                    copyToClipboard("Complete Bash Script Bundle", sb.toString().trim());
                }
            });

        } else if ("links".equals(categoryStyle)) {
            holder.layoutLinks.setVisibility(View.VISIBLE);
            holder.txtTitle.setText(item.getName());
            if (item.getDescription() != null && !item.getDescription().isEmpty()) {
                holder.txtDescription.setText(item.getDescription());
                holder.txtDescription.setVisibility(View.VISIBLE);
            } else {
                holder.txtDescription.setVisibility(View.GONE);
            }

            holder.btnCopyLink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    copyToClipboard("Saved Link URL", item.getDescription());
                }
            });
            holder.btnOpenLink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(item.getDescription()));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(context, "Failed to resolve link browser.", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        } else if ("clipboard".equals(categoryStyle)) {
            holder.layoutClipboard.setVisibility(View.VISIBLE);
            holder.txtTitle.setText("Snippet Payload Block");
            holder.txtDescription.setText("Saved at local memory");
            holder.txtDescription.setVisibility(View.VISIBLE);
            
            holder.txtClipboardContent.setText(item.getContent());
            holder.btnCopyClipboard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    copyToClipboard("Secure Clipboard Snippet", item.getContent());
                }
            });

        } else if ("movies".equals(categoryStyle) || "anime".equals(categoryStyle)) {
            holder.layoutGeneral.setVisibility(View.VISIBLE);
            holder.txtTitle.setText(item.getName());
            if (item.getDescription() != null && !item.getDescription().isEmpty()) {
                holder.txtDescription.setText(item.getDescription());
                holder.txtDescription.setVisibility(View.VISIBLE);
            } else {
                holder.txtDescription.setVisibility(View.GONE);
            }
            
            holder.txtCardBadge.setVisibility(View.VISIBLE);
            holder.txtCardBadge.setText(item.getType().toUpperCase());
            if ("movies".equals(item.getType())) {
                holder.txtCardBadge.setTextColor(context.getResources().getColor(R.color.neon_red));
            } else {
                holder.txtCardBadge.setTextColor(context.getResources().getColor(R.color.neon_purple));
            }

            holder.btnCopyName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    copyToClipboard(item.getType().toUpperCase() + " Title", item.getName());
                }
            });
        }

        return convertView;
    }

    private void copyToClipboard(String label, String text) {
        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText(label, text);
        if (clipboard != null) {
            clipboard.setPrimaryClip(clip);
            Toast.makeText(context, "Copied statement to system clipboard", Toast.LENGTH_SHORT).show();
        }
    }

    public void filter(String query) {
        items.clear();
        if (query.isEmpty()) {
            items.addAll(itemsFull);
        } else {
            String lower = query.toLowerCase().trim();
            for (VaultItem item : itemsFull) {
                if (item.getDescription().toLowerCase().contains(lower) ||
                    item.getName().toLowerCase().contains(lower) ||
                    item.getSearch().toLowerCase().contains(lower) ||
                    item.getContent().toLowerCase().contains(lower)) {
                    items.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }

    public void updateData(List<VaultItem> newItems) {
        this.items = newItems;
        this.itemsFull = new ArrayList<>(newItems);
        notifyDataSetChanged();
    }

    private static class ViewHolder {
        TextView txtTitle, txtDescription, txtCardBadge;
        View btnEdit, btnDelete;
        
        // Regex views
        LinearLayout layoutRegex, layoutRegexReplace;
        TextView txtRegexSearch, txtRegexReplace;
        Button btnCopySearch, btnCopyReplace;

        // Termux views
        LinearLayout layoutTermux, termuxCommandsContainer;
        Button btnCopyAllTermux;

        // Links views
        LinearLayout layoutLinks;
        Button btnOpenLink, btnCopyLink;

        // Clipboard views
        LinearLayout layoutClipboard;
        View btnCopyClipboard;
        TextView txtClipboardContent;

        // General (Movies/Anime) views
        LinearLayout layoutGeneral;
        Button btnCopyName;

        public ViewHolder(View itemView) {
            txtTitle = itemView.findViewById(R.id.txtTitle);
            txtDescription = itemView.findViewById(R.id.txtDescription);
            txtCardBadge = itemView.findViewById(R.id.txtCardBadge);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);

            layoutRegex = itemView.findViewById(R.id.layoutRegexBlock);
            layoutRegexReplace = itemView.findViewById(R.id.layoutRegexReplace);
            txtRegexSearch = itemView.findViewById(R.id.txtRegexSearch);
            txtRegexReplace = itemView.findViewById(R.id.txtRegexReplace);
            btnCopySearch = itemView.findViewById(R.id.btnCopySearch);
            btnCopyReplace = itemView.findViewById(R.id.btnCopyReplace);

            layoutTermux = itemView.findViewById(R.id.layoutTermuxBlock);
            termuxCommandsContainer = itemView.findViewById(R.id.termuxCommandsContainer);
            btnCopyAllTermux = itemView.findViewById(R.id.btnCopyAllTermux);

            layoutLinks = itemView.findViewById(R.id.layoutLinksBlock);
            btnOpenLink = itemView.findViewById(R.id.btnOpenLink);
            btnCopyLink = itemView.findViewById(R.id.btnCopyLink);

            layoutClipboard = itemView.findViewById(R.id.layoutClipboardBlock);
            btnCopyClipboard = itemView.findViewById(R.id.btnCopyClipboard);
            txtClipboardContent = itemView.findViewById(R.id.txtClipboardContent);

            layoutGeneral = itemView.findViewById(R.id.layoutGeneralBlock);
            btnCopyName = itemView.findViewById(R.id.btnCopyName);
        }
    }
}
