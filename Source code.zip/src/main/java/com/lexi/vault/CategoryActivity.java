package com.lexi.vault;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class CategoryActivity extends Activity implements VaultListAdapter.OnItemActionListener {

    private String categoryType;
    private PrefsManager prefs;
    private List<VaultItem> categoryItems;

    private TextView txtCategoryTitle, txtCategorySubtitle;
    private EditText editSearch;
    private ImageButton btnClearSearch;
    private ListView recyclerVault;
    private VaultListAdapter adapter;
    private LinearLayout layoutEmpty;
    private Button btnInsert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        categoryType = getIntent().getStringExtra("category_type");
        if (categoryType == null) categoryType = "regex";

        prefs = PrefsManager.getInstance(this);

        // Bind layout views
        txtCategoryTitle = findViewById(R.id.txtCategoryTitle);
        txtCategorySubtitle = findViewById(R.id.txtCategorySubtitle);
        editSearch = findViewById(R.id.editSearch);
        btnClearSearch = findViewById(R.id.btnClearSearch);
        recyclerVault = findViewById(R.id.recyclerVault);
        layoutEmpty = findViewById(R.id.layoutEmpty);
        btnInsert = findViewById(R.id.btnInsert);

        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });

        setupHeader();
        loadItems();

        // Setup ListView adapter
        adapter = new VaultListAdapter(this, categoryItems, this);
        recyclerVault.setAdapter(adapter);

        checkEmptyState();

        // Search listener
        editSearch.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    adapter.filter(s.toString());
                    btnClearSearch.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
                }

                @Override
                public void afterTextChanged(Editable s) {}
            });

        btnClearSearch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editSearch.setText("");
                }
            });

        // Insert action
        btnInsert.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showItemDialog(null);
                }
            });
    }

    private void setupHeader() {
        if ("regex".equals(categoryType)) {
            txtCategoryTitle.setText("REGEX VAULT");
            txtCategorySubtitle.setText("Text manipulation & patterns");
        } else if ("termux".equals(categoryType)) {
            txtCategoryTitle.setText("TERMUX SHORTCUTS");
            txtCategorySubtitle.setText("Local scripts & terminal sequences");
        } else if ("links".equals(categoryType)) {
            txtCategoryTitle.setText("WEB PORTALS");
            txtCategorySubtitle.setText("Secured link access portals");
        } else if ("clipboard".equals(categoryType)) {
            txtCategoryTitle.setText("SECURE CLIPBOARD");
            txtCategorySubtitle.setText("Encrypted cache snippets");
        } else if ("movies".equals(categoryType)) {
            txtCategoryTitle.setText("MOVIE WATCHLIST");
            txtCategorySubtitle.setText("Secured watchlist logs");
        } else if ("anime".equals(categoryType)) {
            txtCategoryTitle.setText("ANIME VAULT");
            txtCategorySubtitle.setText("Secured anime protocols");
        }
    }

    private void loadItems() {
        List<VaultItem> all = prefs.getItems();
        categoryItems = new ArrayList<>();
        for (VaultItem item : all) {
            if (categoryType.equals(item.getType())) {
                categoryItems.add(item);
            }
        }
    }

    private void checkEmptyState() {
        layoutEmpty.setVisibility(categoryItems.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onEdit(VaultItem item) {
        showItemDialog(item);
    }

    @Override
    public void onDelete(final VaultItem item) {
        new AlertDialog.Builder(this)
            .setTitle("CONFIRM DELETION")
            .setMessage("Are you sure you want to permanently erase this record from the local enclave?")
            .setPositiveButton("DESTRUCT", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    prefs.deleteItem(item.getId());
                    loadItems();
                    adapter.updateData(categoryItems);
                    checkEmptyState();
                    Toast.makeText(CategoryActivity.this, "Erase complete.", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("ABORT", null)
            .show();
    }

    private void showItemDialog(final VaultItem existingItem) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_item, null);
        builder.setView(dialogView);

        // Created as final so inner classes can access it without compiler errors
        final AlertDialog dialog = builder.create();

        // Let standard window handle background colors, or standard attributes
        TextView dialogTitle = dialogView.findViewById(R.id.dialogTitle);
        dialogTitle.setText(existingItem == null ? "COMMIT NEW ENTRY" : "EDIT ENCLAVE RECORD");

        // Input containers
        View groupRegex = dialogView.findViewById(R.id.inputGroupRegex);
        View groupTermux = dialogView.findViewById(R.id.inputGroupTermux);
        View groupLinks = dialogView.findViewById(R.id.inputGroupLinks);
        View groupClipboard = dialogView.findViewById(R.id.inputGroupClipboard);
        View groupGeneral = dialogView.findViewById(R.id.inputGroupGeneral);

        // Inputs
        final EditText editDialogRegexDesc = dialogView.findViewById(R.id.editDialogRegexDesc);
        final EditText editDialogRegexSearch = dialogView.findViewById(R.id.editDialogRegexSearch);
        final EditText editDialogRegexReplace = dialogView.findViewById(R.id.editDialogRegexReplace);

        final EditText editDialogTermuxDesc = dialogView.findViewById(R.id.editDialogTermuxDesc);
        final EditText editDialogTermuxCodes = dialogView.findViewById(R.id.editDialogTermuxCodes);

        final EditText editDialogLinkURL = dialogView.findViewById(R.id.editDialogLinkURL);
        final EditText editDialogLinkName = dialogView.findViewById(R.id.editDialogLinkName);

        final EditText editDialogClipContent = dialogView.findViewById(R.id.editDialogClipContent);

        TextView txtGeneralNameLabel = dialogView.findViewById(R.id.txtGeneralNameLabel);
        final EditText editDialogGeneralName = dialogView.findViewById(R.id.editDialogGeneralName);
        final EditText editDialogGeneralDesc = dialogView.findViewById(R.id.editDialogGeneralDesc);

        Button btnDialogCancel = dialogView.findViewById(R.id.btnDialogCancel);
        Button btnDialogSave = dialogView.findViewById(R.id.btnDialogSave);

        // Hide/Show correct input group based on category
        if ("regex".equals(categoryType)) {
            groupRegex.setVisibility(View.VISIBLE);
            if (existingItem != null) {
                editDialogRegexDesc.setText(existingItem.getDescription());
                editDialogRegexSearch.setText(existingItem.getSearch());
                editDialogRegexReplace.setText(existingItem.getReplace());
            }
        } else if ("termux".equals(categoryType)) {
            groupTermux.setVisibility(View.VISIBLE);
            if (existingItem != null) {
                editDialogTermuxDesc.setText(existingItem.getDescription());
                StringBuilder sb = new StringBuilder();
                for (String code : existingItem.getCodes()) {
                    sb.append(code).append("\n");
                }
                editDialogTermuxCodes.setText(sb.toString().trim());
            }
        } else if ("links".equals(categoryType)) {
            groupLinks.setVisibility(View.VISIBLE);
            if (existingItem != null) {
                editDialogLinkURL.setText(existingItem.getDescription());
                editDialogLinkName.setText(existingItem.getName());
            }
        } else if ("clipboard".equals(categoryType)) {
            groupClipboard.setVisibility(View.VISIBLE);
            if (existingItem != null) {
                editDialogClipContent.setText(existingItem.getContent());
            }
        } else if ("movies".equals(categoryType) || "anime".equals(categoryType)) {
            groupGeneral.setVisibility(View.VISIBLE);
            txtGeneralNameLabel.setText("movies".equals(categoryType) ? "Movie Name" : "Anime Name");
            if (existingItem != null) {
                editDialogGeneralName.setText(existingItem.getName());
                editDialogGeneralDesc.setText(existingItem.getDescription());
            }
        }

        btnDialogCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

        btnDialogSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    VaultItem item = existingItem;
                    if (item == null) {
                        item = new VaultItem(UUID.randomUUID().toString(), categoryType, System.currentTimeMillis());
                    }

                    // Read inputs based on category
                    if ("regex".equals(categoryType)) {
                        String dStr = editDialogRegexDesc.getText().toString().trim();
                        String sStr = editDialogRegexSearch.getText().toString().trim();
                        String rStr = editDialogRegexReplace.getText().toString().trim();

                        if (dStr.isEmpty() || sStr.isEmpty()) {
                            Toast.makeText(CategoryActivity.this, "Description and regex search patterns are required", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        item.setDescription(dStr);
                        item.setSearch(sStr);
                        item.setReplace(rStr);

                    } else if ("termux".equals(categoryType)) {
                        String dStr = editDialogTermuxDesc.getText().toString().trim();
                        String codesStr = editDialogTermuxCodes.getText().toString().trim();

                        if (dStr.isEmpty() || codesStr.isEmpty()) {
                            Toast.makeText(CategoryActivity.this, "Shortcut heading and sequence steps are required", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        item.setDescription(dStr);
                        String[] split = codesStr.split("\n");
                        item.setCodes(Arrays.asList(split));

                    } else if ("links".equals(categoryType)) {
                        String uStr = editDialogLinkURL.getText().toString().trim();
                        String nStr = editDialogLinkName.getText().toString().trim();

                        if (uStr.isEmpty() || nStr.isEmpty()) {
                            Toast.makeText(CategoryActivity.this, "URL and destination name are required", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (!uStr.startsWith("http://") && !uStr.startsWith("https://")) {
                            uStr = "https://" + uStr;
                        }
                        item.setDescription(uStr);
                        item.setName(nStr);

                    } else if ("clipboard".equals(categoryType)) {
                        String cStr = editDialogClipContent.getText().toString().trim();
                        if (cStr.isEmpty()) {
                            Toast.makeText(CategoryActivity.this, "Clipboard text payload is required", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        item.setContent(cStr);

                    } else if ("movies".equals(categoryType) || "anime".equals(categoryType)) {
                        String nStr = editDialogGeneralName.getText().toString().trim();
                        String gDescStr = editDialogGeneralDesc.getText().toString().trim();

                        if (nStr.isEmpty()) {
                            Toast.makeText(CategoryActivity.this, "Resource heading name is required", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        item.setName(nStr);
                        item.setDescription(gDescStr);
                    }

                    prefs.saveSingleItem(item);
                    loadItems();
                    adapter.updateData(categoryItems);
                    checkEmptyState();
                    dialog.dismiss();
                    Toast.makeText(CategoryActivity.this, "Securely committed to enclave storage", Toast.LENGTH_SHORT).show();
                }
            });

        dialog.show();
    }
}

