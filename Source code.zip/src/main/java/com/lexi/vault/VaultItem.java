package com.lexi.vault;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class VaultItem {
    private String id;
    private String type; // regex, termux, links, clipboard, movies, anime
    private long createdAt;
    
    // Type specific fields
    private String description; // also used as "notes" or URL destination
    private String search;      // regex search pattern
    private String replace;     // regex replacement pattern
    private List<String> codes; // bash script command series
    private String name;        // links display name, movies/anime actual name
    private String content;     // clipboard text data block

    public VaultItem() {
        this.codes = new ArrayList<>();
    }

    // Comprehensive constructor
    public VaultItem(String id, String type, long createdAt) {
        this.id = id;
        this.type = type;
        this.createdAt = createdAt;
        this.codes = new ArrayList<>();
    }

    public JSONObject toJSONObject() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("id", id);
        obj.put("type", type);
        obj.put("createdAt", createdAt);
        obj.put("description", description != null ? description : "");
        obj.put("search", search != null ? search : "");
        obj.put("replace", replace != null ? replace : "");
        
        JSONArray arr = new JSONArray();
        if (codes != null) {
            for (String code : codes) {
                arr.put(code);
            }
        }
        obj.put("codes", arr);
        obj.put("name", name != null ? name : "");
        obj.put("content", content != null ? content : "");
        return obj;
    }

    public static VaultItem fromJSONObject(JSONObject obj) throws JSONException {
        VaultItem item = new VaultItem();
        item.setId(obj.getString("id"));
        item.setType(obj.getString("type"));
        item.setCreatedAt(obj.getLong("createdAt"));
        item.setDescription(obj.optString("description", ""));
        item.setSearch(obj.optString("search", ""));
        item.setReplace(obj.optString("replace", ""));
        
        JSONArray arr = obj.optJSONArray("codes");
        List<String> list = new ArrayList<>();
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                list.add(arr.getString(i));
            }
        }
        item.setCodes(list);
        
        item.setName(obj.optString("name", ""));
        item.setContent(obj.optString("content", ""));
        return item;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    public String getDescription() { return description != null ? description : ""; }
    public void setDescription(String description) { this.description = description; }

    public String getSearch() { return search != null ? search : ""; }
    public void setSearch(String search) { this.search = search; }

    public String getReplace() { return replace != null ? replace : ""; }
    public void setReplace(String replace) { this.replace = replace; }

    public List<String> getCodes() { return codes != null ? codes : new ArrayList<>(); }
    public void setCodes(List<String> codes) { this.codes = codes; }

    public String getName() { return name != null ? name : ""; }
    public void setName(String name) { this.name = name; }

    public String getContent() { return content != null ? content : ""; }
    public void setContent(String content) { this.content = content; }
}
