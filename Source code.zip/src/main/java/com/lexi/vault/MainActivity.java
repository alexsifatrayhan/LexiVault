package com.lexi.vault;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int REQUEST_CODE_PICK_FILE = 1234;
    private PrefsManager prefs;
    
    private TextView txtTotalCount, txtSyncCount;
    private TextView lblRegexCount, lblTermuxCount, lblLinksCount, lblClipboardCount, lblMoviesCount, lblAnimeCount;
    private Button btnAbout, btnExport, btnImport;
    private EditText editImportPayloadRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = PrefsManager.getInstance(this);

        // Bind Main Stats
        txtTotalCount = findViewById(R.id.txtTotalCount);
        txtSyncCount = findViewById(R.id.txtSyncCount);
        btnAbout = findViewById(R.id.btnAbout);
        btnExport = findViewById(R.id.btnExport);
        btnImport = findViewById(R.id.btnImport);

        // Bind Category counters
        lblRegexCount = findViewById(R.id.lblRegexCount);
        lblTermuxCount = findViewById(R.id.lblTermuxCount);
        lblLinksCount = findViewById(R.id.lblLinksCount);
        lblClipboardCount = findViewById(R.id.lblClipboardCount);
        lblMoviesCount = findViewById(R.id.lblMoviesCount);
        lblAnimeCount = findViewById(R.id.lblAnimeCount);

        // Grid Click listeners
        findViewById(R.id.cardRegex).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCategory("regex");
            }
        });
        findViewById(R.id.cardTermux).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCategory("termux");
            }
        });
        findViewById(R.id.cardLinks).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCategory("links");
            }
        });
        findViewById(R.id.cardClipboard).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCategory("clipboard");
            }
        });
        findViewById(R.id.cardMovies).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCategory("movies");
            }
        });
        findViewById(R.id.cardAnime).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCategory("anime");
            }
        });

        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });

        btnExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showExportDialog();
            }
        });

        btnImport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showImportDialog();
            }
        });

        updateMainStats();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateMainStats();
    }

    private void openCategory(String category) {
        Intent intent = new Intent(MainActivity.this, CategoryActivity.class);
        intent.putExtra("category_type", category);
        startActivity(intent);
    }

    private void updateMainStats() {
        List<VaultItem> items = prefs.getItems();
        
        int total = items.size();
        txtTotalCount.setText(String.valueOf(total));

        int regCount = 0;
        int termCount = 0;
        int linkCount = 0;
        int clipCount = 0;
        int movCount = 0;
        int animCount = 0;

        for (VaultItem item : items) {
            String type = item.getType();
            if ("regex".equals(type)) regCount++;
            else if ("termux".equals(type)) termCount++;
            else if ("links".equals(type)) linkCount++;
            else if ("clipboard".equals(type)) clipCount++;
            else if ("movies".equals(type)) movCount++;
            else if ("anime".equals(type)) animCount++;
        }

        // Set labels
        lblRegexCount.setText(regCount + " locked");
        lblTermuxCount.setText(termCount + " locked");
        lblLinksCount.setText(linkCount + " locked");
        lblClipboardCount.setText(clipCount + " locked");
        lblMoviesCount.setText(movCount + " locked");
        lblAnimeCount.setText(animCount + " locked");

        // Calculate active slots out of 6 possible categories
        int activeSlots = 0;
        if (regCount > 0) activeSlots++;
        if (termCount > 0) activeSlots++;
        if (linkCount > 0) activeSlots++;
        if (clipCount > 0) activeSlots++;
        if (movCount > 0) activeSlots++;
        if (animCount > 0) activeSlots++;

        txtSyncCount.setText(activeSlots + "/6 Slots");
    }

    private void showExportDialog() {
        try {
            List<VaultItem> items = prefs.getItems();
            JSONArray arr = new JSONArray();
            for (VaultItem item : items) {
                arr.put(item.toJSONObject());
            }
            final String backupJson = arr.toString(2);

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            View view = LayoutInflater.from(this).inflate(R.layout.dialog_export, null);
            builder.setView(view);

            final AlertDialog dialog = builder.create();

            EditText editExportPayload = view.findViewById(R.id.editExportPayload);
            editExportPayload.setText(backupJson);

            Button btnExportCancel = view.findViewById(R.id.btnExportCancel);
            Button btnExportCopy = view.findViewById(R.id.btnExportCopy);
            Button btnExportShare = view.findViewById(R.id.btnExportShare);

            btnExportCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            btnExportCopy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("LexiVault Backup", backupJson);
                    if (clipboard != null) {
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(MainActivity.this, "Backup string copied to clipboard!", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            btnExportShare.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_TITLE, "LexiVault Backup JSON");
                    intent.putExtra(Intent.EXTRA_TEXT, backupJson);
                    startActivity(Intent.createChooser(intent, "Share Vault Backup"));
                }
            });

            dialog.show();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to compile backup data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void showImportDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_import, null);
        builder.setView(view);

        final AlertDialog dialog = builder.create();

        final EditText editImportPayload = view.findViewById(R.id.editImportPayload);
        editImportPayloadRef = editImportPayload;

        Button btnSelectBackupFile = view.findViewById(R.id.btnSelectBackupFile);
        Button btnImportCancel = view.findViewById(R.id.btnImportCancel);
        Button btnImportSubmit = view.findViewById(R.id.btnImportSubmit);

        btnSelectBackupFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(Intent.createChooser(intent, "Select Backup File"), REQUEST_CODE_PICK_FILE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "File manager not available: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnImportCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        btnImportSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = editImportPayload.getText().toString().trim();
                if (input.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Input payload cannot be empty!", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    JSONArray arr = new JSONArray(input);
                    List<VaultItem> importedItems = new ArrayList<>();
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject obj = arr.getJSONObject(i);
                        if (!obj.has("id") || !obj.has("type")) {
                            throw new Exception("Missing 'id' or 'type' in item number " + (i + 1));
                        }
                        importedItems.add(VaultItem.fromJSONObject(obj));
                    }

                    if (importedItems.isEmpty()) {
                        Toast.makeText(MainActivity.this, "No valid records found in import dataset.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    mergeAndSaveItems(importedItems);
                    
                    dialog.dismiss();
                    updateMainStats();
                    Toast.makeText(MainActivity.this, "Successfully restored " + importedItems.size() + " records!", Toast.LENGTH_LONG).show();

                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Invalid Backup Format: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface d) {
                editImportPayloadRef = null;
            }
        });

        dialog.show();
    }

    private void mergeAndSaveItems(List<VaultItem> importedItems) {
        List<VaultItem> current = prefs.getItems();
        for (VaultItem imported : importedItems) {
            boolean replaced = false;
            for (int i = 0; i < current.size(); i++) {
                if (current.get(i).getId().equals(imported.getId())) {
                    current.set(i, imported);
                    replaced = true;
                    break;
                }
            }
            if (!replaced) {
                current.add(0, imported);
            }
        }
        prefs.saveItems(current);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PICK_FILE && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                reader.close();
                inputStream.close();
                
                if (editImportPayloadRef != null) {
                    editImportPayloadRef.setText(sb.toString().trim());
                    Toast.makeText(this, "Backup file content loaded!", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Error reading file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
