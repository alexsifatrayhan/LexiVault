package com.lexi.vault;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class AboutActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        ImageButton btnBack = findViewById(R.id.btnAboutBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Connect social buttons
        findViewById(R.id.btnAboutTelegram).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchUrl("https://t.me/sr7mods");
            }
        });

        findViewById(R.id.btnAboutAppStore).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchUrl("https://alexsifatrayhan.github.io/sr7mods-app-store/");
            }
        });

        findViewById(R.id.btnAboutGitHub).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchUrl("https://github.com/alexsifatrayhan");
            }
        });

        findViewById(R.id.btnAboutYouTube).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchUrl("https://www.youtube.com/@sr7mods");
            }
        });

        findViewById(R.id.btnAboutWhatsApp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchUrl("https://wa.me/8801318930997"); // Template phone placeholder or support link
            }
        });

        findViewById(R.id.btnAboutFacebook).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchUrl("https://m.me/sifatrayhan2007");
            }
        });

        findViewById(R.id.btnAboutEmail).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                    emailIntent.setData(Uri.parse("mailto:mrsrff12@gmail.com"));
                    emailIntent.putExtra(Intent.EXTRA_SUBJECT, "LexiVault Developer Feedback");
                    emailIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(emailIntent);
                } catch (Exception e) {
                    Toast.makeText(AboutActivity.this, "No email client installed on this device.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void launchUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Unable to resolve target browser application", Toast.LENGTH_SHORT).show();
        }
    }
}
